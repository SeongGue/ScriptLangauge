var {{ PolygonMarker }} = L.polygon({{location}},
                               {
                                   color:'{{ color }}',
                                   fillColor:'{{ fill_color }}',
                                   fillOpacity:{{ fill_opacity }},
                                   weight:{{ weight }}
                               });
