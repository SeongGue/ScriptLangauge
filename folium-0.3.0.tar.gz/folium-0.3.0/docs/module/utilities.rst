`legend_scaler`
---------------

.. autofunction:: folium.utilities.legend_scaler


`linear_gradient`
-----------------

.. autofunction:: folium.utilities.linear_gradient


`color_brewer`
--------------

.. autofunction:: folium.utilities.color_brewer

`split_six`
-----------

.. autofunction:: folium.utilities.split_six

`image_to_url`
--------------

.. autofunction:: folium.utilities.image_to_url

`write_png`
-----------

.. autofunction:: folium.utilities.write_png


`_parse_size`
-------------

.. autofunction:: folium.utilities._parse_size


