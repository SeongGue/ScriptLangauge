`Element`
---------

.. autoclass:: folium.element.Element
   :members:

`MacroElement`
--------------

.. autoclass:: folium.element.MacroElement
   :members:

`Figure`
--------

.. autoclass:: folium.element.Figure
   :members:

`Html`
------

.. autoclass:: folium.element.Html
   :members:

`Div`
-----

.. autoclass:: folium.element.Div
   :members:

`IFrame`
--------

.. autoclass:: folium.element.IFrame
   :members:

`Link`
------

.. autoclass:: folium.element.Link
   :members:

`JavascriptLink`
----------------

.. autoclass:: folium.element.JavascriptLink
   :members:

`CssLink`
---------

.. autoclass:: folium.element.CssLink
   :members:
