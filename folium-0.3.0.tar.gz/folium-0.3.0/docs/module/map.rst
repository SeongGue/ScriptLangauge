`LegacyMap`
-----------

.. autoclass:: folium.map.LegacyMap
   :members:

`Layer`
-------

.. autoclass:: folium.map.Layer
   :members:

`TileLayer`
-----------

.. autoclass:: folium.map.TileLayer
   :members:

`FeatureGroup`
--------------

.. autoclass:: folium.map.FeatureGroup
   :members:

`LayerControl`
--------------

.. autoclass:: folium.map.LayerControl
   :members:

`Icon`
------

.. autoclass:: folium.map.Icon
   :members:

`Marker`
--------

.. autoclass:: folium.map.Marker
   :members:

`Popup`
-------

.. autoclass:: folium.map.Popup
   :members:

`FitBounds`
-----------

.. autoclass:: folium.map.FitBounds
   :members:

