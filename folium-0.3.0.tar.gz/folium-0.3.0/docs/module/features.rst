`WmsTileLayer`
--------------

.. autoclass:: folium.features.WmsTileLayer
   :members:

`RegularPolygonMarker`
----------------------

.. autoclass:: folium.features.RegularPolygonMarker
   :members:

`Vega`
------

.. autoclass:: folium.features.Vega
   :members:

`GeoJson`
---------

.. autoclass:: folium.features.GeoJson
   :members:

`TopoJson`
----------

.. autoclass:: folium.features.TopoJson
   :members:

`MarkerCluster`
---------------

.. autoclass:: folium.features.MarkerCluster
   :members:

`DivIcon`
---------

.. autoclass:: folium.features.DivIcon
   :members:

`CircleMarker`
--------------

.. autoclass:: folium.features.CircleMarker
   :members:

`LatLngPopup`
-------------

.. autoclass:: folium.features.LatLngPopup
   :members:

`ClickForMarker`
----------------

.. autoclass:: folium.features.ClickForMarker
   :members:

`PolyLine`
----------

.. autoclass:: folium.features.PolyLine
   :members:

`CustomIcon`
------------

.. autoclass:: folium.features.CustomIcon
   :members:

