`Map`
-----

.. autoclass:: folium.folium.Map
   :members:

