`ColorMap`
----------

.. autoclass:: folium.colormap.ColorMap
   :members:

`LinearColormap`
----------------

.. autoclass:: folium.colormap.LinearColormap
   :members:

`StepColormap`
--------------

.. autoclass:: folium.colormap.StepColormap
   :members:

`linear`
--------

.. autodata:: folium.colormap.linear
   :annotation:

