Contributing
============

Choose the sandbox folder of your choice (`~/sandbox` for example)
::

$ cd ~/sandbox

Clone `folium` from github:
::

$ git clone https://github.com/python-visualization/folium

Push code to your fors, and write a pull request.

TODO: end up this section.
