ModuleDescription
*****************

:doc:`Element </module/element>`
================================

.. toctree::
   :maxdepth: 3

   module/element

:doc:`Map </module/map>`
========================

.. toctree::
   :maxdepth: 3
   
   module/map

:doc:`Features </module/features>`
==================================

.. toctree::
   :maxdepth: 3
   
   module/features

:doc:`Folium </module/folium>`
==============================

.. toctree::
   :maxdepth: 3
   
   module/folium

:doc:`Colormap </module/colormap>`
==================================

.. toctree::
   :maxdepth: 3
   
   module/colormap

:doc:`Utilities </module/utilities>`
====================================

.. toctree::
   :maxdepth: 3
   
   module/utilities

